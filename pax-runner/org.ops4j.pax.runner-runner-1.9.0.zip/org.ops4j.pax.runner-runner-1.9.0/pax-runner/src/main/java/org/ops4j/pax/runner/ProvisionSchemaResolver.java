package org.ops4j.pax.runner;

public interface ProvisionSchemaResolver
{

    String resolve( String toResolve );

}
